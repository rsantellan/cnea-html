<?php
$lang["contacto_titulo"] = "Contacto";
$lang["contacto_subtitulo"] = "Para ponerse en contacto con nosotros, por favor completar el siguiente formulario. <br />Los campos con asterico(*) son requeridos.";
$lang["contacto_nombre"] = "Nombre y Apellido *";
$lang["contacto_institucion"] = "Institución";
$lang["contacto_telefono"] = "Teléfono";
$lang["contacto_celular"] = "Celular";
$lang["contacto_email"] = "Correo Electrónico *";
$lang["contacto_consulta"] = "Consulta";
$lang["contacto_denuncias"] = "Descargar formulario de denunacias";
