<?php

if (!defined('BASEPATH'))
  exit('No direct script access allowed');
/* 
 */


$lang["intereses_enlaces_titulo"] = "enlaces de interés";

$lang["intereses_documentos_titulo"] = "documentos de interés";