<?php

if (!defined('BASEPATH'))
  exit('No direct script access allowed');
/* 
 */


$lang["menu_inicio"] = "Inicio";
$lang["menu_cnea"] = "cnea";
$lang["menu_mision"] = "misi&oacute;n";
$lang["menu_objetivos"] = "objetivos";
$lang["menu_integrantes"] = "integrantes";
$lang["menu_instituciones"] = "registro instituciones";
$lang["menu_instituciones_bases"] = "bases";
$lang["menu_instituciones_formulario"] = "formulario";
$lang["menu_instituciones_registro"] = "registro";
$lang["menu_instituciones_reglamento"] = "reglamentaci&oacute;n";
$lang["menu_personas"] = "acreditaciones personales";
$lang["menu_personas_bases"] = "bases";
$lang["menu_personas_formulario"] = "formulario";
$lang["menu_personas_registro"] = "registro";
$lang["menu_personas_reglamento"] = "reglamentaci&oacute;n";
$lang["menu_actas"] = "actas";
$lang["menu_novedades"] = "novedades";
$lang["menu_faq"] = "faq";
$lang["menu_contacto"] = "contacto";