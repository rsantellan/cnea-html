<?php

if (!defined('BASEPATH'))
  exit('No direct script access allowed');
/* 
 */

$lang['novedades_titulo'] = 'novedades';
$lang['novedades_ver_mas'] = 'ver más';
