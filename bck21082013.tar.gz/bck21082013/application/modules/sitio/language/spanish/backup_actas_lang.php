<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');
$lang['actas_titulo']='actas test<br />';
/* End of file actas_lang.php */