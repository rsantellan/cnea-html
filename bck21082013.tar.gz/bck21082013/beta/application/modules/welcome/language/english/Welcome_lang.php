<?php

$lang["welcome"] = "Welcome to this place";
$lang["login"] = "login 1";