<?php

$lang[""] = "";