<div class="content_right img_personas">
    <h1><?php echo lang("personal_base_titulo"); ?></h1>
    <?php echo lang("personal_base_contenido"); ?>
</div>
<!--CONTENT RIGHT-->