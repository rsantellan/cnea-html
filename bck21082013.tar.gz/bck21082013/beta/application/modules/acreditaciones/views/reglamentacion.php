<div class="content_right img_personas">
    <h1><?php echo lang("personal_reglamentacion_titulo"); ?></h1>
    <?php echo lang("personal_reglamentacion_contenido"); ?>
</div>
<!--CONTENT RIGHT-->